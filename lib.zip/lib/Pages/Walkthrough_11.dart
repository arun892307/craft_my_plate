import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';

import 'Onboarding_11.dart';
import 'Onboarding_15.dart';

class Walkthrough_11 extends StatefulWidget {
  const Walkthrough_11({Key? key}) : super(key: key);

  @override
  State<Walkthrough_11> createState() => _Walkthrough_11State();
}

class _Walkthrough_11State extends State<Walkthrough_11> {
  var current_page=0;
  final _key = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.white,
      body: PageView(
        key: _key,
        scrollDirection: Axis.horizontal,
        reverse: false,
        physics: const BouncingScrollPhysics(),
        pageSnapping: true,
        onPageChanged: (index){
          setState(() {
            current_page=index;
          });
        },
        children: [
          Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
               Padding(padding: const EdgeInsets.only(top: 41,left: 255,right:24 ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  fixedSize: const Size(75, 14),
                  backgroundColor:const Color.fromRGBO(232, 224, 234,0.75),
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(4.0))
                  )
                ),
                  onPressed: (){

                    Navigator.pushReplacement(
                        context,
                        PageTransition(
                          child: const Onboarding_15(),
                          type: PageTransitionType.rightToLeftJoined,
                          duration: const Duration(milliseconds: 650),
                          childCurrent: const Onboarding_15(),
                        )

                    );
                  },
                  child: Text("Skip",
                  style: GoogleFonts.lexend(
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    fontStyle: FontStyle.normal,
                    color:const Color.fromRGBO(123, 123, 123,0.75)
                  ),
                  )
              ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30,left: 30,right: 30),
                child: Container(
                  width: MediaQuery.of(context).size.width*0.9,
                  height: MediaQuery.of(context).size.height*0.4,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    image: DecorationImage(
                      image: AssetImage("assets/images/image_1.png"),
                    )
                  ),
                ),
              ),
              const SizedBox(
                height: 0,
              ),
              Text("Create Your Own Plate",
              style: GoogleFonts.lexend(
                color: Colors.black,
                fontSize: 26,
                fontWeight: FontWeight.w400,
              ),
              ),
               Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 30),
                  child: Text("Create unforgettable memories with our unique feature to curate your favorite cuisines and food, tailored to your special occasion.",
                  textAlign:TextAlign.center,
                      style: GoogleFonts.lexend(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w300
                      ),
                  )),
              row(),
              const SizedBox(
                height: 40,
              ),
              Button()
            ],
          ),
          Column(

            children: [
              Padding(padding: const EdgeInsets.only(top: 41,left: 255 ),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        fixedSize: const Size(75, 14),
                        backgroundColor:const Color.fromRGBO(232, 224, 234,0.75),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(4.0))
                        )
                    ),
                    onPressed: (){
                      Navigator.pushReplacement(
                          context,
                          PageTransition(
                            child: const Onboarding_15(),
                            type: PageTransitionType.rightToLeftJoined,
                            duration: const Duration(milliseconds: 450),
                            childCurrent: const Onboarding_15(),
                          )

                      );
                    },
                    child: Text("Skip",
                      style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          fontStyle: FontStyle.normal,
                          color:const Color.fromRGBO(123, 123, 123,0.75)
                      ),
                    )
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10,left: 48,right: 47),
                child: Container(
                  width: MediaQuery.of(context).size.width*0.9,
                  height: MediaQuery.of(context).size.height*0.4,
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      image: DecorationImage(
                        image: AssetImage("assets/images/img_2.png"),
                      )
                  ),
                ),
              ),
               Text("Create Your Own Plate",style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 26,
                 fontWeight: FontWeight.w400,
              ),),
               Padding(
                  padding:const  EdgeInsets.symmetric(horizontal: 40,vertical: 30),
                  child: Text("Create unforgettable memories with our unique feature to curate your favorite cuisines and food, tailored to your special occasion.",
                    textAlign:TextAlign.center,
                    style: GoogleFonts.lexend(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w300
                    ),
                  )),
              row(),
              const SizedBox(
                height: 40,
              ),
              Button()
            ],
          ),
          Column(
            children: [
              Padding(padding: const EdgeInsets.only(top: 41,left: 255,right:24 ),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        fixedSize: const Size(75, 14),
                        backgroundColor:const Color.fromRGBO(232, 224, 234,0.75),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(4.0))
                        )
                    ),
                    onPressed: (){
                      Navigator.pushReplacement(
                          context,
                          PageTransition(
                            child: const Onboarding_15(),
                            type: PageTransitionType.rightToLeftJoined,
                            duration: const Duration(milliseconds: 450),
                            childCurrent: const Onboarding_15(),
                          )

                      );
                    },
                    child: Text("Skip",
                      style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          fontStyle: FontStyle.normal,
                          color:const Color.fromRGBO(123, 123, 123,0.75)
                      ),
                    )
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10,left: 67,right: 66),
                child: Container(
                  width: MediaQuery.of(context).size.width*0.9,
                  height: MediaQuery.of(context).size.height*0.4,
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      image: DecorationImage(
                        image: AssetImage("assets/images/image_3.png"),
                      )
                  ),
                ),
              ),
               Text("Create Your Own Plate",style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 26,
                 fontWeight: FontWeight.w400,
              ),),
               Padding(
                  padding:const EdgeInsets.symmetric(horizontal: 40,vertical: 30),
                  child: Text("Create unforgettable memories with our unique feature to curate your favorite cuisines and food, tailored to your special occasion.",
                    textAlign:TextAlign.center,
                    style: GoogleFonts.lexend(
                        color: Colors.black,
                        fontSize: 16,
                      fontWeight: FontWeight.w300
                    ),
                  )),
              row(),
              const SizedBox(
                height: 40,
              ),
              Button()

            ],
          ),

        ],
      ),
    );
  }
  
  Widget row(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,

      children: [
        current_page==0?const Icon(Icons.rectangle_rounded,size: 12,color: Colors.blue):const Icon(Icons.rectangle_outlined,size: 12,color: Colors.blue,),
        current_page==1?const Icon(Icons.rectangle_rounded,size: 12,color: Colors.blue):const Icon(Icons.rectangle_outlined,size: 12,color: Colors.blue,),
        current_page==2?const Icon(Icons.rectangle_rounded,size: 12,color: Colors.blue):const Icon(Icons.rectangle_outlined,size: 12,color: Colors.blue,)
      ],
    );
  }

  Widget Button(){
    return InkWell(
      onTap: () {},
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        height: 50,
          alignment: Alignment.center,
          width: (current_page==2)?200:50,
        decoration: BoxDecoration(
          color: Colors.blue,
          borderRadius: BorderRadius.circular(50)
        ),
        child: (current_page==2)
                     ?
            const Text("Get Started")
                     :
            const Icon(Icons.arrow_forward_outlined,color: Colors.white,size: 35)
        
    ),
      
    );
  }
}
