import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class home_screen extends StatelessWidget {
  home_screen({super.key});
  List<String> tc=["Starters","Drinks","Rice","Curry","Desserts"];
  List<String> starters=["Grill Chicken","Mashroom Fry","Veggies Fry"];
  List<String> main_course=["Briyani","Bread","Plan Rice"];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        //forceMaterialTransparency: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.white,
        elevation: 0,
        title: AutoSizeText(
          "Hi, Monica!",
          style: GoogleFonts.lexend(
              color: const Color.fromRGBO(99, 24, 175, 1),
              fontSize: 30,
              fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 15.0,right: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AutoSizeText(
                        "Current location",
                        style: GoogleFonts.lexend(
                            color: Colors.black54,
                            fontSize: 16,
                            fontWeight: FontWeight.w400),
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on_outlined,
                            color: Color.fromRGBO(99, 24, 175, 1),
                          ),
                          AutoSizeText(
                            "Hyderabad",
                            style: GoogleFonts.lexend(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      const Icon(
                        Icons.play_circle_outline,
                        color: Color.fromRGBO(99, 24, 175, 1),
                      ),
                      AutoSizeText(
                        "How it works?",
                        style: GoogleFonts.lexend(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w400),
                      ),
                    ],
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: size.height * 0.2,
              width: size.width,
              child: ListView.builder(
                itemCount: 4,
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.only(left: 10,top: 10),
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Container(
                    height: size.height * 0.2,
                    width: size.width * 0.86,
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(13)),
                        image: DecorationImage(
                            image: AssetImage("assets/images/food1.png"),
                            fit: BoxFit.fill)),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Center(
              child: SizedBox(
                height: size.height * 0.06,
                width: size.width * 0.86,
                child: Material(
                  borderRadius: BorderRadius.circular(12),
                  elevation: 5,
                  shadowColor: Colors.grey[100],
                  child: TextField(
                    decoration: InputDecoration(
                        hintText: "Search food or events",
                        hintStyle: GoogleFonts.lexend(
                            color: Colors.grey[700],
                            fontSize: 16,
                            fontWeight: FontWeight.w300),
                        suffixIcon: const Icon(
                          Icons.search,
                          color: Color.fromRGBO(99, 24, 175, 1),
                        ),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: Colors.grey)),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide:
                                const BorderSide(color: Colors.grey))),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            AutoSizeText(
              "    Start crafting",
              style: GoogleFonts.lexend(
                  color: const Color.fromRGBO(99, 24, 175, 1),
                  fontSize: 22,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 15,
            ),
            SizedBox(
              //height: size.height * 0.2,
              width: size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Material(
                    elevation: 3,
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    child: Column(
                      children: [
                        Container(

                          height: size.height * 0.1,
                          width: size.width * 0.4,
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                              image: DecorationImage(
                                  image: AssetImage("assets/images/food2.png"),
                                  fit: BoxFit.fill)),
                        ),
                        SizedBox(
                          height: size.height * 0.04,
                          width: size.width*0.4,
                           child: Center(
                             child: AutoSizeText(
                               "Default Platters",
                               style: GoogleFonts.lexend(
                                   color: Colors.black,
                                   fontSize: 15,
                                   fontWeight: FontWeight.w500),
                             ),
                           ),
                        )
                      ],
                    ),
                  ),
                  Material(
                    elevation: 3,
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    child: Column(
                      children: [
                        Container(
                          height: size.height * 0.1,
                          width: size.width * 0.4,
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                              image: DecorationImage(
                                  image: AssetImage("assets/images/food3.png"),
                                  fit: BoxFit.fill)),
                        ),
                        SizedBox(
                          height: size.height * 0.04,
                          width: size.width*0.4,
                           child: Center(
                             child: AutoSizeText(
                               "Default Platters",
                               style: GoogleFonts.lexend(
                                   color: Colors.black,
                                   fontSize: 15,
                                   fontWeight: FontWeight.w500),
                             ),
                           ),
                        )
                      ],
                    ),
                  ),

                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            SizedBox(
              height: size.height*0.22,
              child: ListView.builder(
                //padding: const EdgeInsets.only(right: 20,bottom: 8,top: 8),
                scrollDirection: Axis.horizontal,
                itemCount: 4,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.only(right: 15,bottom: 8,top: 8,left: 10),
                  child: Stack(
                  children: [
                    Row(
                      children: [
                        SizedBox(width: size.width*0.045,),
                        Material(
                            elevation: 3,
                            shadowColor: Colors.grey[700],
                            borderRadius: const BorderRadius.all(Radius.circular(12)),
                            child: Container(
                              width: size.width*0.4,
                              padding: const EdgeInsets.fromLTRB(15, 5, 10, 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  AutoSizeText(
                                    "Default Menu ${index+1}",
                                    style: GoogleFonts.lexend(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  const SizedBox(
                                    height: 15,
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: AutoSizeText(
                                      "3 starters\n3 maincourse\n3 desserts\n3 drinks",
                                      style: GoogleFonts.lexend(
                                          color: Colors.black,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              const Icon(Icons.person,color: Colors.grey,size: 18,),
                                              AutoSizeText(
                                                " Min 800",
                                                style: GoogleFonts.lexend(
                                                    color: Colors.grey,
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w400),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          AutoSizeText(
                                            "Starts at \u{20B9} 777",
                                            style: GoogleFonts.lexend(
                                                color: const Color.fromRGBO(99, 24, 175, 1),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w500),
                                          )
                                        ],
                                      )),],
                              ),
                            )
                        ),
                      ],
                    ),
                    Column(

                      children: [
                        SizedBox(height: size.height*0.017,),
                        Container(
                          height: size.width*0.27,
                          width: size.width*0.27,
                          decoration: const BoxDecoration(
                              image: DecorationImage(image: AssetImage("assets/images/food4_2.png"))
                          ),
                        )
                      ],
                    ),
                  ],
              ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            AutoSizeText(
              "    Top Categories",
              style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: size.height*0.15,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 8,left: 22),
                scrollDirection: Axis.horizontal,
                itemCount: 5,
                itemBuilder: (context, index) =>
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(right: 8),
                          height: size.height*0.083,
                          width: size.width*0.18,
                          decoration: BoxDecoration(
                            image: DecorationImage(image: AssetImage("assets/images/tc${index+1}.png"),fit: BoxFit.fill)
                          ),
                        ),
                        AutoSizeText(
                          tc[index],
                          style: GoogleFonts.lexend(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.w300),
                        ),
                  ],
                )
              ),
            ),
            AutoSizeText(
              "    Starters",
              style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: size.height*0.18,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 8,left: 22,bottom: 3),
                  scrollDirection: Axis.horizontal,
                  itemCount: 6,
                  itemBuilder: (context, index) =>
                      SizedBox(
                        width: size.width*0.4,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 10,left: 5),
                          child: Material(
                            elevation: 3,
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(

                                  height: size.height * 0.12,
                                  width: size.width * 0.4,
                                  decoration: BoxDecoration(
                                      borderRadius: const BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                                      image: DecorationImage(
                                          image: AssetImage("assets/images/starter${index%3}.png"),
                                          fit: BoxFit.fill)),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5,left: 10),
                                  child: AutoSizeText(
                                    starters[index%3],
                                    style: GoogleFonts.lexend(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            AutoSizeText(
              "    Main Course",
              style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: size.height*0.18,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 8,left: 22,bottom: 3),
                scrollDirection: Axis.horizontal,
                itemCount: 6,
                itemBuilder: (context, index) =>
                    SizedBox(
                      width: size.width*0.4,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 10,left: 5),
                        child: Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(Radius.circular(15)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(

                                height: size.height * 0.12,
                                width: size.width * 0.4,
                                decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                                    image: DecorationImage(
                                        image: AssetImage("assets/images/main${index%3}.png"),
                                        fit: BoxFit.fill)),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 5,left: 10),
                                child: AutoSizeText(
                                  main_course[index%3],
                                  style: GoogleFonts.lexend(
                                      color: Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            AutoSizeText(
              "    Services",
              style: GoogleFonts.lexend(
                  color: Colors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: size.height*0.18,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 8,left: 22,bottom: 3),
                scrollDirection: Axis.horizontal,
                itemCount: 6,
                itemBuilder: (context, index) =>
                    SizedBox(
                      width: size.width*0.4,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 10,left: 5),
                        child: Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(Radius.circular(15)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(

                                height: size.height * 0.12,
                                width: size.width * 0.4,
                                decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                                    image: DecorationImage(
                                        image: AssetImage("assets/images/main${index%3}.png"),
                                        fit: BoxFit.fill)),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 5,left: 10),
                                child: AutoSizeText(
                                  main_course[index%3],
                                  style: GoogleFonts.lexend(
                                      color: Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
              ),
            ),


          ],
        ),
      ),

    );
  }
}
